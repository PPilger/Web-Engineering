function rollDice() {
	var oAuto = $("img#car1");
	oAuto.fadeOut(1000,function(){
		$("div#spielfeldStart").append(oAuto);
		oAuto.fadeIn(1000);
	});
	
	
	
}